package com.lector.epub

import android.Manifest
import android.app.Activity
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.webkit.WebViewAssetLoader

object Shared { var json = ""; var rate = 1f; var lang = "" }

class MainActivity : Activity() {
    lateinit var web: WebView
    var chooser: ValueCallback<Array<Uri>>? = null

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val js = if (i.action == "lector.PROGRESS") "window.onNativeProgress&&onNativeProgress(${i.getIntExtra("i", 0)})"
                     else "window.onNativeStop&&onNativeStop()"
            web.post { web.evaluateJavascript(js, null) }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun speak(json: String, rate: Float, lang: String) {
            Shared.json = json; Shared.rate = rate; Shared.lang = lang
            startForegroundService(Intent(this@MainActivity, TtsService::class.java).setAction("play"))
        }
        @JavascriptInterface fun stop() {
            startService(Intent(this@MainActivity, TtsService::class.java).setAction("stop"))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        web = WebView(this); setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 7)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        val f = IntentFilter().apply { addAction("lector.PROGRESS"); addAction("lector.STOP") }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        if (r == 7) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c, d)); chooser = null }
    }

    override fun onDestroy() { unregisterReceiver(rx); super.onDestroy() }
}
