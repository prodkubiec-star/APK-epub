package com.lector.epub

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import java.util.Locale

class TtsService : Service(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var ready = false
    private var pending = false
    private var wl: PowerManager.WakeLock? = null
    private var secs = JSONArray()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("tts", "Lectura", NotificationManager.IMPORTANCE_LOW))
        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lector:tts")
    }

    override fun onInit(s: Int) { ready = s == TextToSpeech.SUCCESS; if (ready && pending) play() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") { stopAll(); return START_NOT_STICKY }
        startForeground(1, notif())
        if (ready) play() else pending = true
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, TtsService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "tts").setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Leyendo en voz alta").setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Detener", stop).build()).build()
    }

    private fun play() {
        pending = false
        if (wl?.isHeld == false) wl?.acquire(6 * 3600 * 1000L)
        tts.stop()
        secs = JSONArray(Shared.json)
        tts.language = if (Shared.lang.isNotEmpty()) Locale(Shared.lang) else Locale.getDefault()
        tts.setSpeechRate(Shared.rate)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String) {
                val p = u.split(":")
                if (p[1] == "0") sendBroadcast(Intent("lector.PROGRESS").setPackage(packageName)
                    .putExtra("i", secs.getJSONObject(p[0].toInt()).getInt("i")))
            }
            override fun onDone(u: String) { if (u.endsWith(":L")) speakSec(u.split(":")[0].toInt() + 1) }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String) { stopAll() }
        })
        speakSec(0)
    }

    private fun speakSec(k: Int) {
        if (k >= secs.length()) { stopAll(); return }
        val ch = secs.getJSONObject(k).getJSONArray("c")
        if (ch.length() == 0) { speakSec(k + 1); return }
        for (j in 0 until ch.length()) {
            val id = "$k:$j" + if (j == ch.length() - 1) ":L" else ""
            tts.speak(ch.getString(j), TextToSpeech.QUEUE_ADD, null, id)
        }
    }

    private fun stopAll() {
        tts.stop()
        if (wl?.isHeld == true) wl?.release()
        sendBroadcast(Intent("lector.STOP").setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
